<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="css/style.css">

    <title>Payment Gateway</title>
</head>

<body>
    <!-- header panel  -->
    <?php include 'header.php' ?>

    <div class="container">
        <div class="row" id="content">
            <div class="hero-text">
            <h1 class="text-center" id="text">Welcome to payment gatway integration</h1>
            </div>
        </div>          

    </div>
    <div class="container">
        <div class="row text-center" id="button">
   
        <a href="form.php" class="btn btn-primary">Make Payment</a>
       <a href="about.php" class="btn btn-primary">About us</a> 
        </div>
        
        </div>

        <footer>
        <div class="container">
            <center>
                <h4>Made by &copy shahim Shaikh 2021</h4>
            </center>

        </div>

        </footer>





</body>

</html>