<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="css/style.css">
    <title>Document</title>
</head>
<body>


<?php include 'header.php' ?>

    <div class="container-fluid decor-bg" id="content">
        <div class="row">
            <div class="container">
                <div class="col-md-6 col-md-offset-4 col-md-6 col-md-offset-3">
                    <h1 style="color: whitesmoke;" id="text" class="text-center">Checkout Form</h1>
                    <form action="checkout.php" method="POST">
                        <div class="form-group">
                            <input type="text" placeholder="Name" name="name" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <input type="email" placeholder="Email" name="email" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <input type="number" placeholder="Number" name="phone" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <input type="number" placeholder="Amount" name="amount" class="form-control" required>
                        </div>
                        <input type="submit" value="Pay Now" class="btn-block btn-danger">
                    </form>



                </div>

            </div>

        </div>


    </div>
    
</body>
</html>