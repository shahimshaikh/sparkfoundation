<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <link rel="stylesheet" type="text/css" href="css/style.css">

    <title>Document</title>
</head>
<body>

<?php include 'header.php' ?>
<style>
.circle{
    padding-top: 100px;
    padding: 5%;
}
.col-sm-12{
    background-color: rgba(0,0,0,0.7);
    padding: 10%;
}


</style>

<div class="container">
    <div class="row text-center circle" id="content">
        <div class="col-sm-12" style="color: white;">
            <img src="img/shahim11.jpg" class="img-thumbnail" alt="shahim" width="150" >
            <h3>Shahim Shaikh</h3>
            <p>Please contact me for payment gateway intigration</p>
            <p>Email:- sshahim.shaikh@gmail.com</p>

        </div>

    </div>


</div>
    
</body>
</html>